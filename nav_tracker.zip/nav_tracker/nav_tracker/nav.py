import rclpy  # Imports the core ROS 2 Python client library
from rclpy.node import Node  # Imports the base Node class to create a ROS 2 node
from nav_msgs.msg import Odometry  # Imports the message type used by the /odom topic
import math

class Robot_pos_xy(Node):  # Creates a custom class that inherits from the ROS 2 Node class
    def __init__(self):  # The constructor method that runs when the node is created
        super().__init__('robot_tracker_node')
        
        # Creates a subscriber to listen to the '/odom' topic 
        self.odom_sub = self.create_subscription(Odometry, '/odom', self.odom_callback, 10)   # It triggers 'odom_callback' every time a new message arrives, keeping a queue of 10
    # note : other subscribers like open cv depth cloud go here

    def odom_callback(self, msg):  # This runs automatically when it gets odoom values
        y = msg.pose.pose.position.y  
        x = msg.pose.pose.position.x
       
        #3d pos

        qx = msg.pose.pose.orientation.x
        qy = msg.pose.pose.orientation.y
        qz = msg.pose.pose.orientation.z
        qw = msg.pose.pose.orientation.w

        #math for angle that the robot is looking at
        siny_cosp = 2 * (qw * qz + qx * qy)
        cosy_cosp = 1 - 2 * (qy * qy + qz * qz)
        yaw_rad = math.atan2(siny_cosp, cosy_cosp)
        yaw_deg = math.degrees(yaw_rad)#convert to degrees 

        self.get_logger().info(f'Location -> X: {x:.2f}, Y: {y:.2f} | Facing: {yaw_deg:.1f}°')

def main(args=None):  
    rclpy.init(args=args)  #init for ros2 file
    node = Robot_pos_xy()  #activate node
    rclpy.spin(node)  # Keeps the node running 
    node.destroy_node() 
    rclpy.shutdown() 

if __name__ == '__main__': 
    main()